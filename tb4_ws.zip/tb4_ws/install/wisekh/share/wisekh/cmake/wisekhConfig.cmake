# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_wisekh_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED wisekh_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(wisekh_FOUND FALSE)
  elseif(NOT wisekh_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(wisekh_FOUND FALSE)
  endif()
  return()
endif()
set(_wisekh_CONFIG_INCLUDED TRUE)

# output package information
if(NOT wisekh_FIND_QUIETLY)
  message(STATUS "Found wisekh: 0.0.0 (${wisekh_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'wisekh' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${wisekh_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(wisekh_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${wisekh_DIR}/${_extra}")
endforeach()
